# Handing V3 to Claude Code

Everything Claude Code needs is in one file: **`docs/features/E12_v3-ui.md`**. It is written to be
implementable without the mockup open. This page is only about getting it in and running the sessions.

---

## 1. Put the file in the repo

Copy `docs/features/E12_v3-ui.md` from this zip into your working copy at the same path:

```
C:\dev\portfolio-builder\docs\features\E12_v3-ui.md      (Windows)
~/Developer/portfolio-builder/docs/features/E12_v3-ui.md  (Mac)
```

Then branch and commit it on its own, before any code:

```
git checkout main
git pull
git checkout -b dev-v3ui
git add docs/features/E12_v3-ui.md
git commit -m "E12: V3 UI design spec (design approved, no code yet)"
```

Committing the spec first means every later commit can be read against it, and a session that drifts
can be diffed against a fixed target.

Optional, and worth two minutes: add the epic to `docs/board.json` and re-render the dashboard —

```
py -3 tools/render_dashboard.py
```

## 2. Open the session with the read-back, not with work

Paste **§10 "Session opener"** verbatim. It asks Claude Code to read the spec plus the three governing
sections of the baseline, then state back four things: what is out of scope, what §6 says to delete,
what the hero period figure is computed against, and which §4.9 rows have no pixel in the mockup.

Do not skip this. Those four are exactly what an implementer gets wrong by default — it will refactor
the engine, keep the rail and the cards because they already exist and already pass tests, compute the
return as `last − first`, and quietly drop the features that had no mockup. Ninety seconds of read-back
is cheaper than finding any of them three cards later.

If any of the four comes back wrong, correct it and ask again before starting card 0.

## 3. One card per session, in order

Cards are §8. Start with **E12.0 (shell) alone** — it deletes the rail and rewrites the token block,
so everything else depends on it being right. Then 0b, 1, 2, 3, 4, 5, 6, 7, and APP2 last.

For each card, paste the **§10 "Per-card prompt"**, substituting the card number and name. It points at
that card's §4 subsection *and* its §4.9 rows, and asks for two reports at the end: the element IDs it
had to move, and which §4.9 rows it implemented or couldn't.

End every card with:

```
py -3 tools/check_syntax.py
npx playwright test <the specs named in that card's row of §8>
```

…then click through it yourself in the browser before starting the next one. Commit per card.

**Test against the dev database** — `portfolio-dev` on port 8766 with `portfolio.dev.json`. Never the
real book. Check `portfolio.json`'s md5 against `C:\dev\portfolio-builder-backups\` after any session
that could have touched it.

## 4. Answer four questions before card 0

They are listed at the end of §10 and they change what gets built:

1. Light-only for E12, with dark as its own card (E12.7)? Recommended: yes.
2. Portfolio colours — adopt the five-step ramp, or keep the colour picker and snap the chosen hue onto
   the ramp's lightness steps?
3. The `1D` intraday series — accumulate points during the session, or add a `dsIntraday` adapter
   behind the `ds*` seam? Do not fake it from the daily series.
4. iOS storage — account-only, or on-device as the primary store for a single user? This blocks APP2,
   not the web cards, so it can wait; but answer it before card 8, not during it.

## 5. Rules for the whole epic

- Never let a session merge to `main`. You merge, after clicking through the entire epic.
- If it proposes a number, a policy or a copy string that is not in the spec, it should ask rather than
  choose. The spec is the design of record.
- Ask for the element-ID diff every card. The 84 IDs are the contract that keeps the existing render
  and listener code working; a moved ID is the likeliest cause of a silent break.
- Anything that touches the engine or the `ds*` data layer is a wrong diff, full stop.

---

## The mockup

The clickable mockup stays in the design project — it is the visual reference for *you*, not an input
Claude Code can render. Where the two disagree, **the spec wins**: it is the contract, and it covers
several things the mockup deliberately does not draw (search results, presets, portfolio renaming,
live prices by portfolio, the equal-weight counterfactual). §4.9 lists all of them.

If you want a static copy of the mockup in the repo for reference, ask and I'll export one to
`docs/proto/v3ui.html`.
